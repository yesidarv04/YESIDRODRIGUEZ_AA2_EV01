package yesidrodriguezvi;

public class MainApp {
    public static void main(String[] args) {
        // Crear una instancia de UsuarioDAOImpl
        UsuarioDAO usuarioDAO = new UsuarioDAOImpl();

        // Probar la conexión a la base de datos
        if (usuarioDAO.testConnection()) {
            System.out.println("Conexión exitosa a la base de datos");
        } else {
            System.out.println("Error al conectar a la base de datos");
            return; // Salir si no se puede conectar
        }

        // Realizar operaciones en la base de datos
        Usuario usuarioNuevo = new Usuario("NuevoUsuario", "nuevo@usuario.com");
        if (usuarioDAO.insertUsuario(usuarioNuevo)) {
            System.out.println("Usuario insertado exitosamente");
        } else {
            System.out.println("Error al insertar usuario");
        }

        // Más operaciones...

        // Cerrar la conexión a la base de datos
        usuarioDAO.closeConnection();
    }
}
