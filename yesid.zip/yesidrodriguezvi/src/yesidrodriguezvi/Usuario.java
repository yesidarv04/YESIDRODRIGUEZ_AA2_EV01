package yesidrodriguezvi;

public class Usuario {

    public Usuario(String nuevoUsuario, String nuevousuariocom) {
    }
    private int id;
    private String nombre;
    private String correo;

    // Constructor, getters y setters

    // Ejemplo de getter para id
    public int getId() {
        return id;
    }

    // Ejemplo de setter para id
    public void setId(int id) {
        this.id = id;
    }

    // Getter para nombre
    public String getNombre() {
        return nombre;
    }

    // Setter para nombre
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Getter para correo
    public String getCorreo() {
        return correo;
    }

    // Setter para correo
    public void setCorreo(String correo) {
        this.correo = correo;
    }
}
